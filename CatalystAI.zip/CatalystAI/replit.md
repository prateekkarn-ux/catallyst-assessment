# Overview

This is a React-based landing page for Catallyst, a digital and AI transformation consultancy targeting CEOs and executive leadership. The application features a modern B2B SaaS interface with assessment tools (DigiReady Quick Check and AI Readiness Compass) designed to evaluate organizational readiness for digital transformation. The platform serves as a lead generation and client qualification tool, guiding executives through assessments and toward strategy consultations.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
- **Framework**: React 18 with TypeScript in a Single Page Application (SPA) architecture
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: React Query (TanStack Query) for server state management with local React state for UI interactions
- **Component Library**: Radix UI primitives with shadcn/ui component system for consistent, accessible UI components
- **Styling**: Tailwind CSS with CSS variables for theme support (light/dark mode toggle)

## Design System
- **UI Framework**: shadcn/ui "new-york" style variant providing a professional B2B aesthetic
- **Typography**: Inter font family for exceptional readability and professional appearance
- **Color System**: HSL-based color palette with CSS custom properties supporting both light and dark themes
- **Component Hierarchy**: Modular component architecture with clear separation between presentation and logic components

## Data Architecture
- **Database**: PostgreSQL with Drizzle ORM for type-safe database interactions
- **Schema**: Minimal user schema with extensible design for future assessment data storage
- **Database Provider**: Neon Database (serverless PostgreSQL) for scalable cloud hosting

## Assessment Engine
- **Question System**: JSON-based question definitions with support for trust scoring metrics
- **Scoring Algorithm**: Weighted scoring system that calculates readiness levels and trust scores
- **Results Processing**: Client-side calculation with structured result objects for consistent data handling

## Lead Generation System
- **Form Validation**: Multi-stage validation with email verification and business email detection
- **Lead Qualification**: Corporate email validation to filter out personal email addresses
- **Integration Ready**: Structured for CRM integration and lead nurturing workflows

## External Integrations
- **Calendar Booking**: Calendly integration for strategy consultation scheduling
- **Email Validation**: Mock email validation system (ready for real API integration)
- **Analytics Ready**: Component structure supports analytics integration for conversion tracking

## Build System
- **Build Tool**: Vite for fast development and optimized production builds
- **Development**: Hot module replacement with error overlay for enhanced developer experience
- **TypeScript**: Full TypeScript support with strict type checking across client, server, and shared modules
- **Module Resolution**: Path aliases for clean import statements and better code organization

# External Dependencies

## Core Frontend Dependencies
- **React Ecosystem**: React 18, React DOM, React Query for state management
- **Routing**: Wouter for lightweight single-page application routing
- **Form Handling**: React Hook Form with Hookform Resolvers for form validation
- **UI Components**: Radix UI primitives providing accessible, unstyled component foundations

## Styling and Design
- **CSS Framework**: Tailwind CSS for utility-first styling approach
- **Component Variants**: Class Variance Authority (CVA) for type-safe component variant management
- **Utility Libraries**: clsx and tailwind-merge for conditional class name handling

## Database and Backend
- **ORM**: Drizzle ORM for type-safe database operations and schema management
- **Database**: PostgreSQL via Neon Database serverless platform
- **Validation**: Zod for runtime type validation and schema definition
- **Session Management**: Connect-pg-simple for PostgreSQL session storage

## Development Tools
- **Build System**: Vite with React plugin for fast development and production builds
- **TypeScript**: Full TypeScript support with strict type checking
- **Development Enhancement**: Replit-specific plugins for enhanced development experience in Replit environment

## Third-Party Services
- **Font Delivery**: Google Fonts for Inter font family
- **Calendar Integration**: Calendly for appointment scheduling
- **Development Platform**: Replit for cloud-based development environment

## Utility Libraries
- **Date Handling**: date-fns for consistent date manipulation
- **UI Enhancements**: Various carousel, tooltip, and interaction libraries for rich user experience
- **Icons**: Lucide React for consistent iconography throughout the application