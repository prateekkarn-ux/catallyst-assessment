import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X } from 'lucide-react';
import CatallystLogo from '@assets/the_ceei_logo_1758736098625.jpg';

interface HeaderProps {
  onBookCall: () => void;
}

export default function Header({ onBookCall }: HeaderProps) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center space-x-3">
            <img 
              src={CatallystLogo} 
              alt="Catallyst"
              className="h-10 w-auto"
              data-testid="img-logo"
            />
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <a href="#solutions" className="text-foreground hover:text-primary transition-colors" data-testid="link-solutions">
              Solutions
            </a>
            <a href="#assessments" className="text-foreground hover:text-primary transition-colors" data-testid="link-assessments">
              Assessments
            </a>
            <a href="#about" className="text-foreground hover:text-primary transition-colors" data-testid="link-about">
              About
            </a>
            <Button 
              onClick={onBookCall}
              data-testid="button-book-call-header"
              className="hover-elevate"
            >
              Book Strategy Call
            </Button>
          </nav>

          {/* Mobile Menu Button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            data-testid="button-mobile-menu"
          >
            {isMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 space-y-4">
            <a href="#solutions" className="block text-foreground hover:text-primary transition-colors" data-testid="link-solutions-mobile">
              Solutions
            </a>
            <a href="#assessments" className="block text-foreground hover:text-primary transition-colors" data-testid="link-assessments-mobile">
              Assessments
            </a>
            <a href="#about" className="block text-foreground hover:text-primary transition-colors" data-testid="link-about-mobile">
              About
            </a>
            <Button 
              onClick={onBookCall}
              className="w-full hover-elevate"
              data-testid="button-book-call-mobile"
            >
              Book Strategy Call
            </Button>
          </nav>
        )}
      </div>
    </header>
  );
}