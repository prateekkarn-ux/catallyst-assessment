import { Button } from '@/components/ui/button';
import { ArrowRight, CheckCircle } from 'lucide-react';
import HeroImage from '@assets/generated_images/Corporate_executives_strategic_meeting_71d4f95a.png';

interface HeroSectionProps {
  onGetStarted: () => void;
  onBookCall: () => void;
}

export default function HeroSection({ onGetStarted, onBookCall }: HeroSectionProps) {
  return (
    <section className="relative min-h-screen flex items-center pt-20">
      {/* Background with gradient overlay */}
      <div className="absolute inset-0">
        <img
          src={HeroImage}
          alt="Executive team discussing digital transformation"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/70 via-black/50 to-black/30" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-24">
        <div className="max-w-3xl">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight" data-testid="text-hero-title">
            Transform Your Organization with 
            <span className="text-primary"> Proven Results</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-gray-200 mb-8 leading-relaxed" data-testid="text-hero-subtitle">
            Stop struggling with digital transformation that delivers unclear ROI. 
            Catallyst's 100-Day Sprint methodology converts your investments into measurable growth.
          </p>

          {/* Key Benefits */}
          <div className="grid md:grid-cols-2 gap-4 mb-8">
            {[
              'Scale pilots to enterprise-wide impact',
              'Unlock the "frozen middle" resistance',
              'Align leadership on digital priorities',
              'Build board-ready impact dashboards'
            ].map((benefit, index) => (
              <div key={index} className="flex items-center space-x-3">
                <CheckCircle className="w-5 h-5 text-primary flex-shrink-0" />
                <span className="text-white" data-testid={`text-benefit-${index}`}>{benefit}</span>
              </div>
            ))}
          </div>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Button 
              size="lg" 
              onClick={onGetStarted}
              className="bg-primary hover:bg-primary/90 text-primary-foreground border-primary-border hover-elevate group"
              data-testid="button-get-started"
            >
              Start Free Assessment
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            
            <Button 
              size="lg" 
              variant="outline"
              onClick={onBookCall}
              className="bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
              data-testid="button-book-strategy-call"
            >
              Book Strategy Call
            </Button>
          </div>

          {/* Trust Indicators */}
          <div className="mt-12 pt-8 border-t border-white/20">
            <p className="text-gray-300 text-sm mb-4">Trusted by Fortune 500 CEOs</p>
            <div className="text-white/60 text-sm">
              "We achieved 300% ROI in digital adoption within 100 days" - Fortune 500 CEO
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}