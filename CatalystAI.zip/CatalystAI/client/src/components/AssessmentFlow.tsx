import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { ArrowLeft, ArrowRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

interface Question {
  id: number;
  text: string;
  isTrust?: boolean;
}

interface AssessmentFlowProps {
  assessmentType: 'digiready' | 'ai-readiness';
  onComplete: (results: AssessmentResults) => void;
  onBack: () => void;
}

interface AssessmentResults {
  score: number;
  level: string;
  responses: Record<number, number>;
  trustScore?: number;
}

export default function AssessmentFlow({ assessmentType, onComplete, onBack }: AssessmentFlowProps) {
  //todo: remove mock functionality - replace with real assessment data
  const digiReadyQuestions: Question[] = [
    { id: 1, text: "I actively look for opportunities to use new digital tools or methods to improve work outcomes." },
    { id: 2, text: "I am confident in using digital tools and data to make informed decisions." },
    { id: 3, text: "I adapt quickly to changes in digital processes, tools, or platforms." },
    { id: 4, text: "I encourage my colleagues or teams to adopt and experiment with new digital solutions." },
    { id: 5, text: "I ensure that digital initiatives in my role/team align with organizational goals." },
    { id: 6, text: "I actively keep up with emerging digital trends relevant to my role or industry." }
  ];

  const aiReadinessQuestions: Question[] = [
    { id: 1, text: "We have a clear, business‑aligned AI direction." },
    { id: 2, text: "Our AI vision explicitly aims to build stakeholder trust.", isTrust: true },
    { id: 3, text: "Leaders champion AI adoption and fund it." },
    { id: 4, text: "Leaders communicate AI benefits and limits transparently.", isTrust: true },
    { id: 5, text: "We can access the data we need for AI." },
    { id: 6, text: "Data used for AI is accurate and its source is known.", isTrust: true },
    { id: 7, text: "Our tech stack can run and scale AI." },
    { id: 8, text: "AI outputs are explainable to users.", isTrust: true },
    { id: 9, text: "People are open to using AI in daily work." },
    { id: 10, text: "Employees believe AI recommendations are fair and helpful.", isTrust: true },
    { id: 11, text: "AI is improving process speed/quality." },
    { id: 12, text: "Teams act on AI recommendations with confidence.", isTrust: true },
    { id: 13, text: "AI enhances personalization and service." },
    { id: 14, text: "Customers are informed when AI is used in decisions.", isTrust: true },
    { id: 15, text: "Our infrastructure is reliable for AI workloads." },
    { id: 16, text: "AI decisions can be audited post‑hoc.", isTrust: true },
    { id: 17, text: "AI projects comply with privacy/security standards." },
    { id: 18, text: "Security practices build trust in AI systems.", isTrust: true },
    { id: 19, text: "We follow clear AI ethics guidelines." },
    { id: 20, text: "We regularly check AI for fairness and explainability.", isTrust: true }
  ];

  const questions = assessmentType === 'digiready' ? digiReadyQuestions : aiReadinessQuestions;
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [responses, setResponses] = useState<Record<number, number>>({});

  const progress = ((currentQuestion + 1) / questions.length) * 100;
  
  const handleResponse = (value: number) => {
    setResponses(prev => ({ ...prev, [questions[currentQuestion].id]: value }));
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    } else {
      calculateResults();
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };

  const calculateResults = () => {
    const totalQuestions = questions.length;
    const totalScore = Object.values(responses).reduce((sum, score) => sum + score, 0);
    const averageScore = totalScore / totalQuestions;

    let level: string;
    let trustScore: number | undefined;

    if (assessmentType === 'digiready') {
      if (averageScore >= 4.0) level = 'Digital Trailblazer';
      else if (averageScore >= 3.0) level = 'Digital Advocate';
      else if (averageScore >= 2.0) level = 'Digital Explorer';
      else level = 'Digital Starter';
    } else {
      // AI Readiness
      const trustResponses = questions
        .filter(q => q.isTrust)
        .map(q => responses[q.id])
        .filter(r => r !== undefined);
      
      trustScore = trustResponses.length > 0 
        ? trustResponses.reduce((sum, score) => sum + score, 0) / trustResponses.length 
        : undefined;

      if (averageScore >= 4.3) level = 'Disruptor';
      else if (averageScore >= 3.5) level = 'Transformer';
      else if (averageScore >= 3.0) level = 'Integrator';
      else if (averageScore >= 2.0) level = 'Experimenter';
      else level = 'Starter';
    }

    onComplete({
      score: averageScore,
      level,
      responses,
      trustScore
    });
  };

  const currentResponse = responses[questions[currentQuestion].id];
  const canProceed = currentResponse !== undefined;

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4 max-w-3xl">
        {/* Header */}
        <div className="mb-8">
          <Button 
            variant="ghost" 
            onClick={onBack}
            className="mb-4 hover-elevate"
            data-testid="button-back-to-start"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <h1 className="text-2xl font-bold" data-testid="text-assessment-title">
                {assessmentType === 'digiready' ? 'DigiReady Quick Check' : 'AI Readiness Compass'}
              </h1>
              <Badge variant="outline">
                {currentQuestion + 1} of {questions.length}
              </Badge>
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Progress</span>
                <span>{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" data-testid="progress-assessment" />
            </div>
          </div>
        </div>

        {/* Question Card */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-xl leading-relaxed" data-testid="text-current-question">
              {questions[currentQuestion].text}
            </CardTitle>
            {questions[currentQuestion].isTrust && (
              <Badge variant="secondary" className="w-fit">Trust Factor</Badge>
            )}
          </CardHeader>
          
          <CardContent className="space-y-6">
            <div className="space-y-3">
              <p className="text-sm text-muted-foreground mb-4">
                Rate your agreement with this statement:
              </p>
              
              <div className="grid gap-3">
                {[
                  { value: 1, label: 'Strongly Disagree' },
                  { value: 2, label: 'Disagree' },
                  { value: 3, label: 'Neutral' },
                  { value: 4, label: 'Agree' },
                  { value: 5, label: 'Strongly Agree' }
                ].map((option) => (
                  <Button
                    key={option.value}
                    variant={currentResponse === option.value ? "default" : "outline"}
                    className={`w-full justify-start text-left hover-elevate ${
                      currentResponse === option.value ? 'bg-primary text-primary-foreground' : ''
                    }`}
                    onClick={() => handleResponse(option.value)}
                    data-testid={`button-response-${option.value}`}
                  >
                    <div className="flex items-center space-x-3">
                      <div className={`w-4 h-4 rounded-full border-2 ${
                        currentResponse === option.value 
                          ? 'bg-current border-current' 
                          : 'border-muted-foreground'
                      }`} />
                      <div className="flex-1">
                        <div className="font-medium">{option.label}</div>
                        <div className="text-sm opacity-70">Score: {option.value}</div>
                      </div>
                    </div>
                  </Button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between">
          <Button 
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            className="hover-elevate"
            data-testid="button-previous"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>
          
          <Button 
            onClick={handleNext}
            disabled={!canProceed}
            className="hover-elevate"
            data-testid="button-next"
          >
            {currentQuestion === questions.length - 1 ? 'Complete Assessment' : 'Next Question'}
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </div>
    </div>
  );
}