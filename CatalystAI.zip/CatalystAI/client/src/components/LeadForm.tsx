import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, CheckCircle, X } from 'lucide-react';
import { Alert, AlertDescription } from '@/components/ui/alert';

interface LeadFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: LeadFormData) => void;
  assessmentType: 'digiready' | 'ai-readiness';
}

interface LeadFormData {
  name: string;
  companyName: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  name?: string;
  companyName?: string;
  email?: string;
  phone?: string;
}

export default function LeadForm({ isOpen, onClose, onSubmit, assessmentType }: LeadFormProps) {
  const [formData, setFormData] = useState<LeadFormData>({
    name: '',
    companyName: '',
    email: '',
    phone: ''
  });
  
  const [errors, setErrors] = useState<ValidationErrors>({});
  const [emailValidating, setEmailValidating] = useState(false);
  const [emailValid, setEmailValid] = useState<boolean | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const assessmentTitle = assessmentType === 'digiready' ? 'DigiReady Quick Check' : 'AI Readiness Compass';

  // Mock email validation function (in real app, this would call an API)
  const validateEmail = async (email: string): Promise<boolean> => {
    //todo: remove mock functionality - replace with real email validation API
    const personalDomains = ['gmail.com', 'yahoo.com', 'hotmail.com', 'outlook.com', 'icloud.com'];
    const dummyEmails = ['test@', 'example@', 'demo@', 'fake@'];
    
    // Check for basic email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) return false;
    
    // Check for personal domains
    const domain = email.split('@')[1];
    if (personalDomains.includes(domain)) return false;
    
    // Check for dummy email patterns
    if (dummyEmails.some(dummy => email.toLowerCase().startsWith(dummy))) return false;
    
    return true;
  };

  const handleEmailChange = async (email: string) => {
    setFormData(prev => ({ ...prev, email }));
    setErrors(prev => ({ ...prev, email: undefined }));
    
    if (email.length > 3) {
      setEmailValidating(true);
      setEmailValid(null);
      
      // Debounce validation
      setTimeout(async () => {
        const isValid = await validateEmail(email);
        setEmailValid(isValid);
        setEmailValidating(false);
        
        if (!isValid) {
          setErrors(prev => ({ 
            ...prev, 
            email: 'Please provide a valid corporate email address (no personal or dummy emails)' 
          }));
        }
      }, 500);
    }
  };

  const handlePhoneChange = (phone: string) => {
    // Remove any non-digits
    const cleaned = phone.replace(/\D/g, '');
    
    // Limit to 10 digits
    const limited = cleaned.slice(0, 10);
    
    setFormData(prev => ({ ...prev, phone: limited }));
    setErrors(prev => ({ ...prev, phone: undefined }));
    
    if (limited.length > 0 && limited.length !== 10) {
      setErrors(prev => ({ ...prev, phone: 'Please enter exactly 10 digits' }));
    }
  };

  const validateForm = (): boolean => {
    const newErrors: ValidationErrors = {};
    
    if (!formData.name.trim()) {
      newErrors.name = 'Name is required';
    }
    
    if (!formData.companyName.trim()) {
      newErrors.companyName = 'Company name is required';
    }
    
    if (!formData.email.trim()) {
      newErrors.email = 'Corporate email is required';
    } else if (!emailValid) {
      newErrors.email = 'Please provide a valid corporate email address';
    }
    
    if (!formData.phone || formData.phone.length !== 10) {
      newErrors.phone = 'Please enter a valid 10-digit phone number';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    
    // Simulate API call
    setTimeout(() => {
      onSubmit(formData);
      setIsSubmitting(false);
    }, 1000);
  };

  const handleClose = () => {
    setFormData({ name: '', companyName: '', email: '', phone: '' });
    setErrors({});
    setEmailValid(null);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={handleClose}>
      <DialogContent className="sm:max-w-md" data-testid="dialog-lead-form">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle data-testid="text-lead-form-title">
              Start Your {assessmentTitle}
            </DialogTitle>
            <Button 
              variant="ghost" 
              size="icon"
              onClick={handleClose}
              data-testid="button-close-form"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </DialogHeader>
        
        <Card>
          <CardHeader className="pb-4">
            <CardTitle className="text-lg">Contact Information</CardTitle>
            <p className="text-sm text-muted-foreground">
              We'll send your personalized assessment report to your email.
            </p>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {/* Name Field */}
              <div className="space-y-2">
                <Label htmlFor="name">Full Name *</Label>
                <Input
                  id="name"
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter your full name"
                  className={errors.name ? 'border-destructive' : ''}
                  data-testid="input-name"
                />
                {errors.name && (
                  <p className="text-sm text-destructive" data-testid="error-name">{errors.name}</p>
                )}
              </div>

              {/* Company Name Field */}
              <div className="space-y-2">
                <Label htmlFor="companyName">Company Name *</Label>
                <Input
                  id="companyName"
                  type="text"
                  value={formData.companyName}
                  onChange={(e) => setFormData(prev => ({ ...prev, companyName: e.target.value }))}
                  placeholder="Enter your company name"
                  className={errors.companyName ? 'border-destructive' : ''}
                  data-testid="input-company"
                />
                {errors.companyName && (
                  <p className="text-sm text-destructive" data-testid="error-company">{errors.companyName}</p>
                )}
              </div>

              {/* Email Field */}
              <div className="space-y-2">
                <Label htmlFor="email">Corporate Email *</Label>
                <div className="relative">
                  <Input
                    id="email"
                    type="email"
                    value={formData.email}
                    onChange={(e) => handleEmailChange(e.target.value)}
                    placeholder="name@company.com"
                    className={`pr-10 ${errors.email ? 'border-destructive' : emailValid === true ? 'border-chart-2' : ''}`}
                    data-testid="input-email"
                  />
                  <div className="absolute right-3 top-1/2 -translate-y-1/2">
                    {emailValidating ? (
                      <div className="animate-spin w-4 h-4 border-2 border-primary border-t-transparent rounded-full" />
                    ) : emailValid === true ? (
                      <CheckCircle className="w-4 h-4 text-chart-2" data-testid="icon-email-valid" />
                    ) : emailValid === false ? (
                      <AlertCircle className="w-4 h-4 text-destructive" data-testid="icon-email-invalid" />
                    ) : null}
                  </div>
                </div>
                {errors.email && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription data-testid="error-email">{errors.email}</AlertDescription>
                  </Alert>
                )}
              </div>

              {/* Phone Field */}
              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number *</Label>
                <div className="flex">
                  <div className="flex items-center px-3 border border-r-0 rounded-l-md bg-muted text-muted-foreground">
                    +91
                  </div>
                  <Input
                    id="phone"
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => handlePhoneChange(e.target.value)}
                    placeholder="9876543210"
                    className={`rounded-l-none ${errors.phone ? 'border-destructive' : ''}`}
                    maxLength={10}
                    data-testid="input-phone"
                  />
                </div>
                {errors.phone && (
                  <p className="text-sm text-destructive" data-testid="error-phone">{errors.phone}</p>
                )}
              </div>

              {/* Submit Button */}
              <Button 
                type="submit" 
                className="w-full hover-elevate"
                disabled={isSubmitting || !emailValid}
                data-testid="button-submit-form"
              >
                {isSubmitting ? 'Starting Assessment...' : `Start ${assessmentTitle}`}
              </Button>
              
              <p className="text-xs text-muted-foreground text-center">
                By continuing, you agree to receive assessment results and relevant insights from Catallyst.
              </p>
            </form>
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
}