import Footer from '../Footer';

export default function FooterExample() {
  return (
    <Footer onBookCall={() => console.log('Book call clicked from footer')} />
  );
}