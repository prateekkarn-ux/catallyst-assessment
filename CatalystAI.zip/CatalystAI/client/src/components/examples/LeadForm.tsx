import { useState } from 'react';
import LeadForm from '../LeadForm';

export default function LeadFormExample() {
  const [isOpen, setIsOpen] = useState(true);

  return (
    <LeadForm 
      isOpen={isOpen}
      onClose={() => setIsOpen(false)}
      onSubmit={(data) => {
        console.log('Form submitted:', data);
        setIsOpen(false);
      }}
      assessmentType="digiready"
    />
  );
}