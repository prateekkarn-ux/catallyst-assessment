import CEOPainPoints from '../CEOPainPoints';

export default function CEOPainPointsExample() {
  return (
    <CEOPainPoints onBookCall={() => console.log('Book call clicked from pain points')} />
  );
}