import Header from '../Header';

export default function HeaderExample() {
  return (
    <Header onBookCall={() => console.log('Book strategy call clicked')} />
  );
}