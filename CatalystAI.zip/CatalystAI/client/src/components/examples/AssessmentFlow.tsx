import { useState } from 'react';
import AssessmentFlow from '../AssessmentFlow';

export default function AssessmentFlowExample() {
  const [showFlow, setShowFlow] = useState(true);

  if (!showFlow) {
    return (
      <div className="p-8 text-center">
        <p>Assessment completed!</p>
        <button onClick={() => setShowFlow(true)} className="mt-4 px-4 py-2 bg-primary text-white rounded">
          Restart Assessment
        </button>
      </div>
    );
  }

  return (
    <AssessmentFlow 
      assessmentType="digiready"
      onComplete={(results) => {
        console.log('Assessment completed:', results);
        setShowFlow(false);
      }}
      onBack={() => console.log('Back to assessments')}
    />
  );
}