import AssessmentCards from '../AssessmentCards';

export default function AssessmentCardsExample() {
  return (
    <AssessmentCards 
      onStartDigiReady={() => console.log('DigiReady assessment started')}
      onStartAIReadiness={() => console.log('AI Readiness assessment started')}
    />
  );
}