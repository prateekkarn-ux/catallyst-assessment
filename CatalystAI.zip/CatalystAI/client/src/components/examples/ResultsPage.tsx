import ResultsPage from '../ResultsPage';

export default function ResultsPageExample() {
  //todo: remove mock functionality - replace with real results data
  const mockResults = {
    score: 3.7,
    level: 'Digital Advocate',
    responses: { 1: 4, 2: 3, 3: 4, 4: 4, 5: 3, 6: 4 },
    trustScore: 3.2
  };

  return (
    <ResultsPage 
      assessmentType="ai-readiness"
      results={mockResults}
      onDownloadReport={() => console.log('Download report clicked')}
      onBookCall={() => console.log('Book call clicked')}
      onStartOver={() => console.log('Start over clicked')}
    />
  );
}