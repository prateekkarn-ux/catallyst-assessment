import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import CatallystLogo from '@assets/the_ceei_logo_1758736098625.jpg';

interface FooterProps {
  onBookCall: () => void;
}

export default function Footer({ onBookCall }: FooterProps) {
  return (
    <footer className="bg-muted/30 py-16">
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <img 
              src={CatallystLogo} 
              alt="Catallyst"
              className="h-10 w-auto"
              data-testid="img-footer-logo"
            />
            <p className="text-sm text-muted-foreground">
              Transform your organization with proven digital and AI transformation methodologies.
            </p>
            <Button 
              onClick={onBookCall}
              variant="outline"
              size="sm"
              className="hover-elevate"
              data-testid="button-footer-book-call"
            >
              Book Strategy Call
            </Button>
          </div>

          {/* Assessments */}
          <div className="space-y-4">
            <h4 className="font-semibold">Assessments</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#assessments" className="hover:text-foreground transition-colors" data-testid="link-footer-digiready">DigiReady Quick Check</a></li>
              <li><a href="#assessments" className="hover:text-foreground transition-colors" data-testid="link-footer-ai-readiness">AI Readiness Compass</a></li>
            </ul>
          </div>

          {/* Company */}
          <div className="space-y-4">
            <h4 className="font-semibold">Company</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><a href="#about" className="hover:text-foreground transition-colors" data-testid="link-about-footer">About Us</a></li>
              <li><a href="#" className="hover:text-foreground transition-colors" data-testid="link-contact">Contact</a></li>
            </ul>
          </div>
        </div>

        <Separator className="my-8" />

        <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
          <div className="text-sm text-muted-foreground">
            © 2025 Catallyst all rights reserved
          </div>
          <div className="flex space-x-6 text-sm text-muted-foreground">
            <a href="#" className="hover:text-foreground transition-colors" data-testid="link-privacy">Privacy Policy</a>
            <a href="#" className="hover:text-foreground transition-colors" data-testid="link-terms">Terms of Service</a>
            <a href="#" className="hover:text-foreground transition-colors" data-testid="link-cookies">Cookie Policy</a>
          </div>
        </div>
      </div>
    </footer>
  );
}