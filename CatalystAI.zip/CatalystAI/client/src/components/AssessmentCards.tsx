import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, BarChart3, Brain, Users, ArrowRight } from 'lucide-react';

interface AssessmentCardsProps {
  onStartDigiReady: () => void;
  onStartAIReadiness: () => void;
}

export default function AssessmentCards({ onStartDigiReady, onStartAIReadiness }: AssessmentCardsProps) {
  return (
    <section id="assessments" className="py-24 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-assessments-title">
            Discover Your Organization's Readiness
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-assessments-subtitle">
            Take our scientifically-backed assessments to understand where you stand 
            and get personalized recommendations for your transformation journey.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* DigiReady Assessment Card */}
          <Card className="hover-elevate cursor-pointer transition-all duration-300 border-2 hover:border-primary/20" data-testid="card-digiready">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <BarChart3 className="w-8 h-8 text-primary" />
                </div>
                <Badge variant="secondary" className="text-xs">
                  <Clock className="w-3 h-3 mr-1" />
                  2 min
                </Badge>
              </div>
              <CardTitle className="text-2xl" data-testid="text-digiready-title">DigiReady Quick Check</CardTitle>
              <p className="text-muted-foreground" data-testid="text-digiready-description">
                Get a snapshot of your digital readiness across all organizational levels - 
                from individual contributors to executive leadership.
              </p>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <h4 className="font-semibold text-sm uppercase tracking-wide text-muted-foreground">What You'll Discover</h4>
                <ul className="space-y-2">
                  {[
                    'Digital mindset and competence levels',
                    'Adaptability and collaboration readiness', 
                    'Strategic alignment assessment',
                    'Future-readiness capabilities'
                  ].map((item, index) => (
                    <li key={index} className="flex items-start space-x-2 text-sm">
                      <div className="w-1.5 h-1.5 bg-primary rounded-full mt-2 flex-shrink-0" />
                      <span data-testid={`text-digiready-benefit-${index}`}>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-4 border-t">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <div className="text-sm font-medium">Scoring Levels</div>
                    <div className="text-xs text-muted-foreground">Digital Starter → Trailblazer</div>
                  </div>
                  <Users className="w-4 h-4 text-muted-foreground" />
                </div>
                
                <Button 
                  onClick={onStartDigiReady}
                  className="w-full group hover-elevate"
                  data-testid="button-start-digiready"
                >
                  Start DigiReady Assessment
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* AI Readiness Assessment Card */}
          <Card className="hover-elevate cursor-pointer transition-all duration-300 border-2 hover:border-primary/20" data-testid="card-ai-readiness">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between mb-4">
                <div className="p-3 bg-chart-2/10 rounded-lg">
                  <Brain className="w-8 h-8 text-chart-2" />
                </div>
                <Badge variant="secondary" className="text-xs">
                  <Clock className="w-3 h-3 mr-1" />
                  3 min
                </Badge>
              </div>
              <CardTitle className="text-2xl" data-testid="text-ai-readiness-title">AI Readiness Compass</CardTitle>
              <p className="text-muted-foreground" data-testid="text-ai-readiness-description">
                Comprehensive evaluation of your organization's AI maturity across strategy, 
                leadership, data, technology, culture, and governance dimensions.
              </p>
            </CardHeader>
            
            <CardContent className="space-y-6">
              <div className="space-y-3">
                <h4 className="font-semibold text-sm uppercase tracking-wide text-muted-foreground">10 Key Dimensions</h4>
                <ul className="space-y-2">
                  {[
                    'Strategy & Leadership alignment',
                    'Data quality and infrastructure', 
                    'Technology readiness & culture',
                    'Ethics, governance & trust factors'
                  ].map((item, index) => (
                    <li key={index} className="flex items-start space-x-2 text-sm">
                      <div className="w-1.5 h-1.5 bg-chart-2 rounded-full mt-2 flex-shrink-0" />
                      <span data-testid={`text-ai-readiness-benefit-${index}`}>{item}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-4 border-t">
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <div className="text-sm font-medium">Maturity Levels</div>
                    <div className="text-xs text-muted-foreground">Starter → Disruptor</div>
                  </div>
                  <Brain className="w-4 h-4 text-muted-foreground" />
                </div>
                
                <Button 
                  onClick={onStartAIReadiness}
                  className="w-full group hover-elevate"
                  data-testid="button-start-ai-readiness"
                >
                  Start AI Readiness Compass
                  <ArrowRight className="ml-2 w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Bottom CTA */}
        <div className="text-center mt-16">
          <p className="text-muted-foreground mb-4">
            Both assessments are completely free and provide instant, actionable insights.
          </p>
          <p className="text-sm text-muted-foreground">
            Join 500+ executives who have discovered their transformation opportunities.
          </p>
        </div>
      </div>
    </section>
  );
}