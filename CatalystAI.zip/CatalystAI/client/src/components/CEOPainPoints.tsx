import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, TrendingDown, Users, Target, DollarSign, Shield } from 'lucide-react';

interface CEOPainPointsProps {
  onBookCall: () => void;
}

export default function CEOPainPoints({ onBookCall }: CEOPainPointsProps) {
  //todo: remove mock functionality - replace with real CEO objection data
  const painPoints = [
    {
      icon: DollarSign,
      title: "Unclear Digital ROI",
      pain: "We've invested heavily in digital/AI, but business impact is unclear.",
      solution: "Catallyst links digital/AI directly to top-line and bottom-line metrics. Our 100-Day Sprint identifies high-impact initiatives and proves ROI through measurable outcomes.",
      metric: "300% ROI in digital adoption"
    },
    {
      icon: TrendingDown,
      title: "Pilots Don't Scale",
      pain: "Our pilots aren't scaling; value is stuck at proof-of-concept.",
      solution: "We focus on scaling adoption by embedding digital culture across leadership layers. Our DigiReady™ heatmap pinpoints barriers while culture interventions ensure enterprise-wide impact.",
      metric: "95% pilot-to-production success rate"
    },
    {
      icon: Users,
      title: "Frozen Middle Resistance",
      pain: "Culture and middle management resistance slow us down.",
      solution: "Catallyst builds a culture of curiosity, experimentation, and innovation. Through micro-behaviors and Digital Champions, we unlock middle management as transformation drivers.",
      metric: "87% employee adoption rate"
    },
    {
      icon: Target,
      title: "Leadership Misalignment",
      pain: "Leadership isn't aligned on digital priorities.",
      solution: "We create leadership alignment workshops to unify priorities around business outcomes. Our advisory ensures digital is seen as core strategy, not a siloed function.",
      metric: "100% C-suite alignment achieved"
    },
    {
      icon: AlertTriangle,
      title: "Board Pressure",
      pain: "The board demands clarity and future-proofing.",
      solution: "Catallyst equips CEOs with board-ready narratives linking digital investments to growth, competitiveness, and resilience. Our scenario planning prepares for disruption.",
      metric: "Board confidence score: 9.2/10"
    },
    {
      icon: Shield,
      title: "AI Risk & Governance",
      pain: "We worry about responsible AI and risk.",
      solution: "Our programs integrate responsible AI practices—bias mitigation, data governance, compliance—and embed trust as a cultural driver of adoption.",
      metric: "Zero compliance violations"
    }
  ];

  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <Badge variant="outline" className="mb-4">For CEOs & Executive Leaders</Badge>
          <h2 className="text-3xl md:text-4xl font-bold mb-4" data-testid="text-pain-points-title">
            Stop Struggling with Digital Transformation
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto" data-testid="text-pain-points-subtitle">
            CEOs don't fail on vision—they struggle with scaling, alignment, adoption, and ROI. 
            Here's how we solve the challenges that matter most.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {painPoints.map((point, index) => {
            const Icon = point.icon;
            return (
              <Card key={index} className="hover-elevate transition-all duration-300 border-2 hover:border-primary/20">
                <CardHeader className="pb-4">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-destructive/10 rounded-lg">
                      <Icon className="w-6 h-6 text-destructive" />
                    </div>
                    <Badge variant="destructive" className="text-xs">Pain Point</Badge>
                  </div>
                  <CardTitle className="text-lg" data-testid={`text-pain-title-${index}`}>{point.title}</CardTitle>
                </CardHeader>
                
                <CardContent className="space-y-4">
                  <div>
                    <h5 className="font-semibold text-destructive text-sm mb-2">The Challenge:</h5>
                    <p className="text-sm text-muted-foreground" data-testid={`text-pain-description-${index}`}>
                      "{point.pain}"
                    </p>
                  </div>
                  
                  <div>
                    <h5 className="font-semibold text-chart-2 text-sm mb-2">Catallyst Solution:</h5>
                    <p className="text-sm" data-testid={`text-solution-${index}`}>
                      {point.solution}
                    </p>
                  </div>
                  
                  <div className="pt-4 border-t">
                    <div className="flex items-center justify-between">
                      <div className="text-xs text-muted-foreground">Proven Result:</div>
                      <div className="text-sm font-semibold text-primary" data-testid={`text-metric-${index}`}>
                        {point.metric}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* CTA Section */}
        <div className="text-center space-y-6">
          <div className="space-y-4">
            <h3 className="text-2xl font-bold">Ready to Position Yourself as an Architect of Future-Ready Enterprise?</h3>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Join 500+ CEOs who have transformed their organizations from digital adopters to transformation leaders.
            </p>
          </div>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <Button 
              onClick={onBookCall}
              size="lg"
              className="hover-elevate"
              data-testid="button-book-call-pain-points"
            >
              Book Strategy Call
            </Button>
            <Button 
              variant="outline" 
              size="lg"
              onClick={() => document.getElementById('assessments')?.scrollIntoView({ behavior: 'smooth' })}
              className="hover-elevate"
              data-testid="button-start-assessment-pain-points"
            >
              Start Assessment
            </Button>
          </div>

          <div className="mt-8 pt-8 border-t">
            <p className="text-sm text-muted-foreground">
              "Catallyst converted our digital investments into measurable growth in 100 days." - Fortune 500 CEO
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}