import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Download, Calendar, ArrowRight, TrendingUp, Shield, Users, Target } from 'lucide-react';

interface AssessmentResults {
  score: number;
  level: string;
  responses: Record<number, number>;
  trustScore?: number;
}

interface ResultsPageProps {
  assessmentType: 'digiready' | 'ai-readiness';
  results: AssessmentResults;
  onDownloadReport: () => void;
  onBookCall: () => void;
  onStartOver: () => void;
}

export default function ResultsPage({ assessmentType, results, onDownloadReport, onBookCall, onStartOver }: ResultsPageProps) {
  const assessmentTitle = assessmentType === 'digiready' ? 'DigiReady Quick Check' : 'AI Readiness Compass';
  const scorePercentage = (results.score / 5) * 100;
  const trustScorePercentage = results.trustScore ? (results.trustScore / 5) * 100 : undefined;

  //todo: remove mock functionality - replace with real insights
  const getInsights = () => {
    if (assessmentType === 'digiready') {
      return {
        strengths: ['Digital mindset alignment', 'Tool adoption readiness'],
        improvements: ['Strategic alignment', 'Future-readiness planning'],
        recommendations: [
          'Invest in leadership digital literacy programs',
          'Create cross-functional digital innovation teams',
          'Establish clear digital transformation metrics'
        ]
      };
    } else {
      return {
        strengths: ['Data infrastructure', 'Leadership support'],
        improvements: ['AI governance', 'Cultural adoption'],
        recommendations: [
          'Develop comprehensive AI ethics framework',
          'Implement AI literacy training for all levels',
          'Create AI Center of Excellence for governance'
        ]
      };
    }
  };

  const insights = getInsights();

  const getLevelColor = (level: string) => {
    const lowerLevel = level.toLowerCase();
    if (lowerLevel.includes('trailblazer') || lowerLevel.includes('disruptor')) return 'bg-chart-2';
    if (lowerLevel.includes('advocate') || lowerLevel.includes('transformer')) return 'bg-chart-1';
    if (lowerLevel.includes('explorer') || lowerLevel.includes('integrator')) return 'bg-chart-3';
    return 'bg-chart-4';
  };

  const getScoreColor = (score: number) => {
    if (score >= 4.0) return 'text-chart-2';
    if (score >= 3.0) return 'text-chart-1';
    if (score >= 2.0) return 'text-chart-3';
    return 'text-chart-4';
  };

  return (
    <div className="min-h-screen bg-background py-8">
      <div className="container mx-auto px-4 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-4" data-testid="text-results-title">
            Your {assessmentTitle} Results
          </h1>
          <p className="text-muted-foreground">
            Comprehensive analysis of your {assessmentType === 'digiready' ? 'digital readiness' : 'AI maturity'} 
          </p>
        </div>

        {/* Results Overview */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Overall Score */}
          <Card>
            <CardHeader className="text-center pb-4">
              <CardTitle className="flex items-center justify-center gap-2">
                <TrendingUp className="w-5 h-5" />
                Overall Score
              </CardTitle>
            </CardHeader>
            <CardContent className="text-center space-y-4">
              <div className={`text-4xl font-bold ${getScoreColor(results.score)}`} data-testid="text-overall-score">
                {results.score.toFixed(1)}/5.0
              </div>
              <Progress value={scorePercentage} className="h-3" />
              <Badge className={`${getLevelColor(results.level)} text-white text-sm px-4 py-2`} data-testid="badge-level">
                {results.level}
              </Badge>
            </CardContent>
          </Card>

          {/* Trust Score (AI only) */}
          {trustScorePercentage !== undefined && (
            <Card>
              <CardHeader className="text-center pb-4">
                <CardTitle className="flex items-center justify-center gap-2">
                  <Shield className="w-5 h-5" />
                  Trust Score
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-4">
                <div className={`text-4xl font-bold ${getScoreColor(results.trustScore!)}`} data-testid="text-trust-score">
                  {results.trustScore!.toFixed(1)}/5.0
                </div>
                <Progress value={trustScorePercentage} className="h-3" />
                <p className="text-sm text-muted-foreground">
                  Trust in AI systems and processes
                </p>
              </CardContent>
            </Card>
          )}

          {/* Quick Stats (DigiReady only) */}
          {assessmentType === 'digiready' && (
            <Card>
              <CardHeader className="text-center pb-4">
                <CardTitle className="flex items-center justify-center gap-2">
                  <Users className="w-5 h-5" />
                  Readiness Level
                </CardTitle>
              </CardHeader>
              <CardContent className="text-center space-y-4">
                <div className="text-2xl font-bold text-primary" data-testid="text-readiness-percentage">
                  {Math.round(scorePercentage)}%
                </div>
                <Progress value={scorePercentage} className="h-3" />
                <p className="text-sm text-muted-foreground">
                  Digital transformation readiness
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Detailed Analysis */}
        <div className="grid md:grid-cols-2 gap-6 mb-8">
          {/* Strengths */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-chart-2">
                <Target className="w-5 h-5" />
                Key Strengths
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {insights.strengths.map((strength, index) => (
                  <li key={index} className="flex items-start gap-3" data-testid={`text-strength-${index}`}>
                    <div className="w-2 h-2 bg-chart-2 rounded-full mt-2 flex-shrink-0" />
                    <span className="text-sm">{strength}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          {/* Areas for Improvement */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-chart-3">
                <ArrowRight className="w-5 h-5" />
                Growth Areas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-3">
                {insights.improvements.map((improvement, index) => (
                  <li key={index} className="flex items-start gap-3" data-testid={`text-improvement-${index}`}>
                    <div className="w-2 h-2 bg-chart-3 rounded-full mt-2 flex-shrink-0" />
                    <span className="text-sm">{improvement}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </div>

        {/* Recommendations */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="text-xl">Personalized Recommendations</CardTitle>
            <p className="text-muted-foreground">
              Based on your assessment, here are your next steps:
            </p>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {insights.recommendations.map((rec, index) => (
                <div key={index} className="flex items-start gap-4 p-4 rounded-lg bg-muted/30">
                  <div className="bg-primary text-primary-foreground rounded-full w-6 h-6 flex items-center justify-center text-sm font-bold flex-shrink-0">
                    {index + 1}
                  </div>
                  <p className="text-sm" data-testid={`text-recommendation-${index}`}>{rec}</p>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Next Steps */}
        <div className="space-y-4">
          <h3 className="text-xl font-bold text-center mb-6">Ready to Transform Your Organization?</h3>
          
          <div className="grid md:grid-cols-2 gap-4">
            <Button 
              onClick={onDownloadReport}
              size="lg"
              variant="outline"
              className="w-full hover-elevate"
              data-testid="button-download-report"
            >
              <Download className="w-5 h-5 mr-2" />
              Download Full Report
            </Button>
            
            <Button 
              onClick={onBookCall}
              size="lg"
              className="w-full hover-elevate"
              data-testid="button-book-strategy-call-results"
            >
              <Calendar className="w-5 h-5 mr-2" />
              Book Strategy Call
            </Button>
          </div>

          {assessmentType === 'ai-readiness' && (
            <div className="text-center mt-6">
              <p className="text-sm text-muted-foreground mb-4">
                Want the executive summary sample before your full consultation?
              </p>
              <Button 
                variant="ghost" 
                onClick={onDownloadReport}
                data-testid="button-download-executive-summary"
              >
                Download Sample Executive Summary
              </Button>
            </div>
          )}
          
          <div className="text-center mt-8 pt-8 border-t">
            <Button 
              variant="ghost" 
              onClick={onStartOver}
              data-testid="button-start-over"
            >
              Take Another Assessment
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}