import { useState } from 'react';
import Header from '@/components/Header';
import HeroSection from '@/components/HeroSection';
import AssessmentCards from '@/components/AssessmentCards';
import CEOPainPoints from '@/components/CEOPainPoints';
import LeadForm from '@/components/LeadForm';
import AssessmentFlow from '@/components/AssessmentFlow';
import ResultsPage from '@/components/ResultsPage';
import Footer from '@/components/Footer';
import ThemeToggle from '@/components/ThemeToggle';

type AppState = 'home' | 'lead-form' | 'assessment' | 'results';

interface LeadFormData {
  name: string;
  companyName: string;
  email: string;
  phone: string;
}

interface AssessmentResults {
  score: number;
  level: string;
  responses: Record<number, number>;
  trustScore?: number;
}

export default function Home() {
  const [currentState, setCurrentState] = useState<AppState>('home');
  const [selectedAssessment, setSelectedAssessment] = useState<'digiready' | 'ai-readiness'>('digiready');
  const [leadData, setLeadData] = useState<LeadFormData | null>(null);
  const [assessmentResults, setAssessmentResults] = useState<AssessmentResults | null>(null);

  const handleBookCall = () => {
    //todo: remove mock functionality - replace with real Calendly integration
    window.open('https://calendly.com/prateek-karn-catallysts/30min', '_blank');
  };

  const handleStartAssessment = (assessmentType: 'digiready' | 'ai-readiness') => {
    setSelectedAssessment(assessmentType);
    setCurrentState('lead-form');
  };

  const handleLeadFormSubmit = (data: LeadFormData) => {
    setLeadData(data);
    setCurrentState('assessment');
  };

  const handleAssessmentComplete = (results: AssessmentResults) => {
    setAssessmentResults(results);
    setCurrentState('results');
  };

  const handleDownloadReport = () => {
    //todo: remove mock functionality - replace with real PDF generation
    console.log('Generating report for:', leadData, assessmentResults);
    alert('Report generation would happen here with real backend');
  };

  const handleStartOver = () => {
    setCurrentState('home');
    setLeadData(null);
    setAssessmentResults(null);
  };

  const handleBackToHome = () => {
    setCurrentState('home');
  };

  // Home page view
  if (currentState === 'home') {
    return (
      <div className="min-h-screen bg-background">
        <div className="fixed top-4 right-4 z-50">
          <ThemeToggle />
        </div>
        
        <Header onBookCall={handleBookCall} />
        <HeroSection onGetStarted={() => handleStartAssessment('digiready')} onBookCall={handleBookCall} />
        <AssessmentCards onStartDigiReady={() => handleStartAssessment('digiready')} onStartAIReadiness={() => handleStartAssessment('ai-readiness')} />
        <CEOPainPoints onBookCall={handleBookCall} />
        <Footer onBookCall={handleBookCall} />
      </div>
    );
  }

  // Lead form view
  if (currentState === 'lead-form') {
    return (
      <div className="min-h-screen bg-background">
        <div className="fixed top-4 right-4 z-50">
          <ThemeToggle />
        </div>
        <LeadForm
          isOpen={true}
          onClose={handleBackToHome}
          onSubmit={handleLeadFormSubmit}
          assessmentType={selectedAssessment}
        />
      </div>
    );
  }

  // Assessment view
  if (currentState === 'assessment' && leadData) {
    return (
      <div className="min-h-screen bg-background">
        <div className="fixed top-4 right-4 z-50">
          <ThemeToggle />
        </div>
        <AssessmentFlow
          assessmentType={selectedAssessment}
          onComplete={handleAssessmentComplete}
          onBack={handleBackToHome}
        />
      </div>
    );
  }

  // Results view
  if (currentState === 'results' && assessmentResults) {
    return (
      <div className="min-h-screen bg-background">
        <div className="fixed top-4 right-4 z-50">
          <ThemeToggle />
        </div>
        <ResultsPage
          assessmentType={selectedAssessment}
          results={assessmentResults}
          onDownloadReport={handleDownloadReport}
          onBookCall={handleBookCall}
          onStartOver={handleStartOver}
        />
      </div>
    );
  }

  // Fallback
  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <p>Loading...</p>
    </div>
  );
}